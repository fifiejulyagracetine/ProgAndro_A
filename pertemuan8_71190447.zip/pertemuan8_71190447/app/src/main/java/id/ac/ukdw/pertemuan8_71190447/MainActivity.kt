package id.ac.ukdw.pertemuan8_71190447

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import android.widget.Toolbar
import androidx.fragment.app.Fragment
import androidx.fragment.app.ListFragment
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import java.lang.reflect.Array.get
import java.nio.file.Files.size
import java.text.ParsePosition

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setSupportActionBar(findViewById(R.id.toolbar_default))
        supportActionBar?.setDisplayShowHomeEnabled(false)


        val viewPager = findViewById<ViewPager2>(R.id.pager)
        val listFragment: ArrayList<Fragment> = arrayListOf(
            SatuFragment(),
            DuaFragment(),
            TigaFragment()
        )
        val adapter = PagerAdapter(this,listFragment)

        viewPager.adapter = adapter
        viewPager.setCurrentItem(0)
    }

    class PagerAdapter(val activity: AppCompatActivity, val listFragment: ArrayList<Fragment>): FragmentStateAdapter(activity) {
        override fun getItemCount(): Int {
            return listFragment.size
        }
        override fun createFragment(position: Int): Fragment {
            return listFragment.get(position)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        getMenuInflater().inflate(R.menu.menu,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.love -> {
//                Toast.makeText(this,"ini menu profile", Toast.LENGTH_SHORT).show()
                val viewPager = findViewById<ViewPager2>(R.id.pager)
                viewPager.setCurrentItem(0)
                true
            }
            R.id.message -> {
//                Toast.makeText(this,"ini menu setting", Toast.LENGTH_SHORT).show()
                val viewPager = findViewById<ViewPager2>(R.id.pager)
                viewPager.setCurrentItem(1)
                true
            }

            R.id.setting->{
//                Toast.makeText(this,"ini menu chat", Toast.LENGTH_SHORT).show()
                val viewPager = findViewById<ViewPager2>(R.id.pager)
                viewPager.setCurrentItem(2)
                true
            }
        }

        return super.onOptionsItemSelected(item)
    }

}