package id.ac.ukdw.pertemuan8_71190447

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.ListFragment
import androidx.viewpager.widget.ViewPager
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2

class HomeActivity:AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val pager = findViewById<ViewPager2>(R.id.pager)
        val ListFragment: ArrayList<Fragment> = arrayListOf(SatuFragment(),DuaFragment(),TigaFragment())
        val pagerAdapter = PagerAdapter(this, ListFragment)
        pager.adapter = pagerAdapter
    }

    class PagerAdapter(fa: AppCompatActivity, val listFragment: ArrayList<Fragment>): FragmentStateAdapter(fa){
        override fun getItemCount(): Int = listFragment.size
        override fun createFragment(position: Int): Fragment = listFragment[position]
    }
}