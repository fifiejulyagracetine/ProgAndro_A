package id.ac.ukdw.pertemuan11_71190447

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : AppCompatActivity() {
    var firestore: FirebaseFirestore? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        firestore = FirebaseFirestore.getInstance()

        val edtId = findViewById<EditText>(R.id.edtId)
        val edtNama = findViewById<EditText>(R.id.edtNama)
        val edtUsia = findViewById<EditText>(R.id.edtUsia)
        val btnSimpan = findViewById<Button>(R.id.btnSimpan)
        val btnCari = findViewById<Button>(R.id.btnCari)
        val txvOutput = findViewById<TextView>(R.id.txvOutput)

        btnSimpan.setOnClickListener{
            val penduduk = Penduduk(edtNama.text.toString(), edtUsia.text.toString().toInt())
            edtNama.setText("")
            edtUsia.setText("")
            firestore?.collection("penduduk")?.add(penduduk)
        }

        btnCari.setOnClickListener{
            firestore?.collection("penduduk")?.document(edtId.text.toString())?.get()!!
                .addOnSuccessListener{doc ->
                    txvOutput.setText(doc.data.toString())
                }
        }
    }
}