package id.ac.ukdw.pertemuan11_71190447

data class Penduduk(val nama: String, val usia: Int)
